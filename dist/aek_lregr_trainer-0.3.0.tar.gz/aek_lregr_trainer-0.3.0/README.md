<div align="center">
  <img src="https://raw.githubusercontent.com/alpemre8/aek-img-trainer/main/logo.png" alt="AEK Automatic ANN/DNN Linear Regression and Classification TrainerLogo" width="400"/>
  
  # AEK Automatic ANN/DNN Linear Regression and Classification Trainer
  
  AI Automatic ANN/DNN Linear Regression and Classification Library 
</div>
